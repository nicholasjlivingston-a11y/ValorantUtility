# Data Dictionary: VALORANT Analytical Stats Layer Relational Tables

## 1. Table: `players.parquet`
* **player_id** (STRING): Primary key, stable UUID of the play agent character.
* **player_name** (STRING): Display name of the agent character.
* **codename** (STRING): Design concept name of the character.
* **team_id** (STRING): Mapped team grouping.

## 2. Table: `rounds.parquet`
* **round_id** (INT): Match-scoped unique round counter.
* **match_id** (STRING): Friendly UUID name of the processed match.
* **start_time_ms** (INT): Setup round start offset.
* **end_time_ms** (INT): Final round completion timestamp.

## 3. Table: `spike_events.parquet`
* **event_id** (STRING): Mapped unique spike action index.
* **round_id** (INT): Reference index linking back to rounds.
* **event_type** (STRING): Classification string ('SpikePlanted', 'SpikeDefused', etc.).
* **time_ms** (INT): Millisecond tick relative to match time.

## 4. Table: `kills.parquet`
* **kill_id** (STRING): Stable primary key index.
* **round_id** (INT): Mapped round index.
* **time_ms** (INT): Elimination millisecond offset.
* **killer_id** (STRING): Mapped character UUID of the slayer.
* **victim_id** (STRING): Mapped character UUID of the victim.
* **weapon_name** (STRING): Instrument of combat.

## 5. Table: `damage_events.parquet`
* **damage_id** (STRING): Structural primary key.
* **round_id** (INT): Mapped round index.
* **attacker_id** (STRING): Attacking agent UUID.
* **victim_id** (STRING): Recipient agent UUID.
* **damage_amount** (INT): Calculated raw damage applied.
* **lethal** (BOOLEAN): Status indicating killing blow.

## 6. Table: `economy.parquet`
* **player_id** (STRING): Reference linking to the players register.
* **round_id** (INT): Active round index.
* **loadout_value** (INT): Value of items in hand.
* **remaining_credits** (INT): Credit balance.
* **armor_class** (STRING): Status of shields.

## 7. Table: `ability_casts.parquet`
* **cast_id** (STRING): Unique cast index.
* **player_id** (STRING): Casting character UUID.
* **ability_name** (STRING): Name of casted ability.
* **time_ms** (INT): Timing index offset.

## 8. Table: `player_state.parquet` (4 Hz Tracking)
* **state_id** (STRING): Tick index reference identifier.
* **time_ms** (INT): Interval-quantized timeline timestamp (250ms spacing).
* **character_net_guid** (INT): Stable engine entity tracking ID.
* **norm_x** (FLOAT): Normal horizontal coordinate scaled within [0.0, 1.0].
* **norm_y** (FLOAT): Normal vertical coordinate scaled within [0.0, 1.0].
* **pos_z** (FLOAT): Raw engine height component.
