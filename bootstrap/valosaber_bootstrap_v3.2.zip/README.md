# Valosaber pipeline bootstrap v3.2.0

Built 2026-11-06 from repo commit e19f69c. Serves two consumers from one raw `.vrf` replay:
the **meta-analysis agent** (15 native-resolution data groups, `analytics_tables/`) and the **statistics analyst** (schema-2 shard, `stats_shard/`).

## Start here (in this order)
1. `AGENT_TASK.md` is the task you are given. Read all of it, including the ADDENDUM at the end.
2. `docs/EXTRACTION_REQUIREMENTS.md` is the meta agent's contract for `analytics_tables/` (verbatim).
3. `knowledge/` holds what the project has learned: `Reference/Replay Data Guide.md` (traps in the data), agents, classes, maps, abilities,
   ADRs (`Decisions/`), shard schema, metrics. Names are confirmed or they stay as codenames.
4. `parser/meta_tables.py` is reference code that already builds the 15 data groups from one export (read it before writing your own) and `parser/meta_tables_test.py` tests it; unzip `golden_sample/export_full.zip` and run `python3 parser/meta_tables_test.py <unzipped>/export golden_sample/shard`. Its gap list says what is still unbuilt. `knowledge/Pipeline/First Real Run Checklist.md` says what to report after the first real replay.
5. `golden_sample/` is the one replay whose correct answer is known. Run `python3 parser/golden_sample_test.py golden_sample/shard golden_sample/export`
   before trusting any code change. A pass means EXPORT_PIPELINE_VALIDATED (export to shard logic only), not that a raw replay was parsed.

## Layout
| Path | Contents |
|---|---|
| `parser/` | `colab_bootstrap.py` (installs a registered vrfkit), `batch_process.py` (folder of replays to shards), `valosaber.py`, `shard_checks.py`, `golden_sample_test.py`, `ingest.py`, `baselines.py`, `register_vrfkit.py`, `meta_tables.py` + test, `skill/` (cast and table builders, `codenames.json`), notebook |
| `data/` | name lookup (build 13.08), `agent_classes.json`, `vrfkit_supported_builds.json` (registry), pipeline guide |
| `scripts/ schemas/ config/ ontology/ run_pipeline.py` | the meta agent's earlier files, unchanged. `run_pipeline.py` is the old exporter (fixed folders); use `parser/batch_process.py` instead. `scripts/spatial_layer.py` expects CSV tables this pipeline does not yet produce |
| `golden_sample/` | shard, events and manifest of the sample export, the full export zipped, expected values |
| `bin/` | empty on purpose (see `bin/README.txt`) |
| `PACKAGE_MANIFEST.json` | SHA-256 of every file here |

## Run
Normalized data (39 tables, schema norm-1; contract in `docs/DATA_CONTRACT.md`, summary in `docs/HANDOFF.md`):
```
python3 parser/run_pipeline.py --from-exports EXPORTS --out OUT      # existing exports, no vrfkit
python3 parser/run_pipeline.py --replays REPLAYS --vrfkit bin/vrfkit --out OUTBOX   # raw replays
python3 parser/normalize_test.py golden_export_dir                   # after unzipping golden_sample/export_full.zip
```
Shard + analytics route:
```
python3 parser/colab_bootstrap.py          # stops with REFUSING if no registered vrfkit is found
python3 parser/batch_process.py --replays REPLAYS --outbox OUTBOX --vrfkit bin/vrfkit --lookup data/name_lookup_build13_08.json --only ONE_REPLAY.vrf
```
Run one replay first and read its `status.json`. A replay whose build is not in the registry stops with `unsupported_build`; that is the correct
result, not something to work around. Never fill, default or invent a value; never run a binary that is not registered.

## Known limits (today)
- Logic is verified only on release-13.08 Swiftplay. The 13.09 vrfkit exported all 7 Standard matches of the first cohort with 0 decode errors, but nothing downstream is verified on 13.09 Standard until a run is read. Hush's codename and ID are unknown.
- `RoundInfos.StartOfRound*` is zero in the sample (money elsewhere is real). `characterUltimateUsed` over-reports about 50%.
- Built as reference only (13.08 sample): the 15 groups in `parser/meta_tables.py`. Not built: per-hit damage and regions, kill weapon and assists, spike site and planter, ability lifecycle beyond cast and actor open/close, effect intervals, health and alive state, purchases, capability report, tests A to I.
- Economy is not all zero: see `knowledge/Reference/Replay Data Guide.md` item 11.
