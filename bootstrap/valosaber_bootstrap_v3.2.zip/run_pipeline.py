#!/usr/bin/env python3
import subprocess
import pathlib
import sys
import os

def main():
    print("=== VALORANT Automated Telemetry Pipeline ===")
    raw_dir = pathlib.Path("./raw_replays")
    out_dir = pathlib.Path("./parsed_outputs")
    out_dir.mkdir(parents=True, exist_ok=True)

    # Search local raw_replays folder
    vrf_files = list(raw_dir.glob("*.vrf"))
    if not vrf_files:
        vrf_files = list(pathlib.Path(".").glob("**/*.vrf"))

    if not vrf_files:
        print("Error: No raw .vrf replay files found.")
        sys.exit(1)

    bin_path = pathlib.Path("./bin/vrfkit")
    if bin_path.exists():
        os.chmod(bin_path, 0o755)

    print(f"Processing {len(vrf_files)} raw matches...")
    for vf in vrf_files:
        print(f"  Executing export on: {vf.name}...")
        subprocess.run([
            "./bin/vrfkit", "export", str(vf), "--out", str(out_dir / vf.stem), "--checkpoints"
        ], check=True)
    print("\nSuccess! All telemetry files exported successfully inside ./parsed_outputs/")

if __name__ == '__main__':
    main()
