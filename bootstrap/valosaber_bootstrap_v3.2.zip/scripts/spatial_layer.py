#!/usr/bin/env python3
"""Canonical event / provenance layer for the VALORANT replay parser.

Consumes the existing parser's CSV outputs. It does not decode raw .vrf files;
run the existing vrfkit-backed parser first. Missing map metadata and telemetry
remain explicitly unknown. No map names or continuous trajectories are invented.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "0.1.0"
SCHEMA_VERSION = "1.0.0"
OBSERVED = "OBSERVED"
DERIVED = "DERIVED"
UNKNOWN = "UNKNOWN"

EVENT_FIELDS = [
    "event_id", "replay_id", "round_id", "source_table", "source_record_id",
    "source_event_type", "canonical_event_type", "source_timestamp_ms",
    "replay_timestamp_ms", "round_timestamp_ms", "actor_entity_id",
    "target_entity_id", "actor_team", "target_team", "position_x", "position_y",
    "position_z", "ability_instance_id", "object_instance_id",
    "observation_status", "event_order_status", "derivation_version",
    "validation_status", "notes"
]
ABILITY_FIELDS = [
    "replay_id", "round_id", "ability_instance_id", "cast_event_id", "cast_key",
    "caster_entity_id", "caster_team", "agent", "ability", "tier",
    "cast_timestamp_ms", "position_x", "position_y", "position_z",
    "lifecycle_status", "object_class", "link_basis", "link_delta_ms",
    "source_record_id", "confidence_status", "derivation_version"
]
INTERACTION_FIELDS = [
    "interaction_id", "replay_id", "round_id", "ability_instance_id",
    "cast_key", "interaction_type", "timestamp_ms", "target_entity_id",
    "target_team", "value", "effect_lag_s", "source_table",
    "source_record_id", "observation_status", "confidence_status",
    "derivation_version", "notes"
]
FINDING_FIELDS = [
    "finding_id", "replay_id", "check_id", "severity", "status", "message",
    "affected_table", "affected_record_id", "expected_value", "observed_value",
    "downstream_capabilities_blocked", "suggested_investigation"
]

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def stable_id(*parts: Any, prefix: str = "") -> str:
    raw = "|".join("" if p is None else str(p) for p in parts)
    return prefix + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]

def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow({k: _csv_value(row.get(k)) for k in fields})

def _csv_value(v: Any) -> Any:
    if v is None:
        return ""
    if isinstance(v, (dict, list, tuple)):
        return json.dumps(v, sort_keys=True, separators=(",", ":"))
    return v

def _num(row: dict[str, str], *names: str) -> float | None:
    for name in names:
        v = row.get(name)
        if v is None or str(v).strip() == "":
            continue
        try:
            return float(v)
        except (TypeError, ValueError):
            continue
    return None

def _text(row: dict[str, str], *names: str) -> str | None:
    for name in names:
        v = row.get(name)
        if v is not None and str(v).strip() != "":
            return str(v).strip()
    return None

def locate_match_dirs(input_root: Path) -> list[tuple[str, Path]]:
    """Accepts an output root containing matches/<id>, a matches directory, or one tables dir."""
    if (input_root / "matches").is_dir():
        base = input_root / "matches"
        return sorted([(p.name, p) for p in base.iterdir() if p.is_dir()], key=lambda x: x[0])
    if input_root.name == "matches":
        return sorted([(p.name, p) for p in input_root.iterdir() if p.is_dir()], key=lambda x: x[0])
    if (input_root / "match.csv").exists() or (input_root / "timeline.csv").exists():
        return [(input_root.name or "replay", input_root)]
    children = [(p.name, p) for p in input_root.iterdir() if p.is_dir()
                and ((p / "match.csv").exists() or (p / "timeline.csv").exists())]
    return sorted(children, key=lambda x: x[0])

def load_map_metadata(map_metadata_path: Path | None, replay_id: str) -> dict[str, Any]:
    if not map_metadata_path or not map_metadata_path.exists():
        return {"map_id": None, "map_name": None, "map_identity_status": "UNKNOWN",
                "map_evidence": None, "geometry_version": None}
    obj = json.loads(map_metadata_path.read_text(encoding="utf-8"))
    # Supports either {"replays":{"replay-id": {...}}} or one replay object.
    rec = obj.get("replays", {}).get(replay_id, obj)
    if not isinstance(rec, dict):
        rec = {}
    map_id = rec.get("map_id")
    evidence = rec.get("map_evidence")
    status = "VERIFIED" if map_id and evidence else "UNKNOWN"
    return {"map_id": map_id if status == "VERIFIED" else None,
            "map_name": rec.get("map_name") if status == "VERIFIED" else None,
            "map_identity_status": status,
            "map_evidence": evidence if status == "VERIFIED" else None,
            "geometry_version": rec.get("geometry_version") if status == "VERIFIED" else None}

def make_finding(replay_id: str, check_id: str, severity: str, status: str,
                 message: str, table: str = "", record_id: str = "",
                 expected: Any = "", observed: Any = "",
                 blocked: str = "", suggested: str = "") -> dict[str, Any]:
    return {
        "finding_id": stable_id(replay_id, check_id, table, record_id, message, prefix="val_"),
        "replay_id": replay_id, "check_id": check_id, "severity": severity,
        "status": status, "message": message, "affected_table": table,
        "affected_record_id": record_id, "expected_value": expected,
        "observed_value": observed, "downstream_capabilities_blocked": blocked,
        "suggested_investigation": suggested
    }

def process_match(match_key: str, match_dir: Path, output_dir: Path,
                  map_metadata_path: Path | None = None) -> dict[str, Any]:
    source_files = sorted([p for p in match_dir.glob("*.csv") if p.is_file()])
    source_manifest = [{"path": p.name, "bytes": p.stat().st_size, "sha256": sha256_file(p)}
                       for p in source_files]
    match_rows = read_csv(match_dir / "match.csv")
    match_row = match_rows[0] if match_rows else {}
    source_match_id = _text(match_row, "match_id")
    # Input identity is based on the source files, not folder names or player IDs.
    replay_id = "replay_" + stable_id(
        *[(x["path"], x["sha256"]) for x in source_manifest], prefix=""
    )
    map_meta = load_map_metadata(map_metadata_path, replay_id)
    if map_meta["map_identity_status"] == "UNKNOWN":
        # Also allow metadata keyed by the source match_id.
        alt = load_map_metadata(map_metadata_path, source_match_id or "")
        if alt["map_identity_status"] == "VERIFIED":
            map_meta = alt

    findings: list[dict[str, Any]] = []
    if not source_files:
        findings.append(make_finding(replay_id, "source_files_present", "ERROR", "FAIL",
            "No parser CSV outputs found.", suggested="Run the existing replay parser first."))
    if not source_match_id:
        findings.append(make_finding(replay_id, "match_id_present", "ERROR", "FAIL",
            "match.csv is missing or has no match_id; stable replay_id is still generated from source file hashes.",
            "match.csv", blocked="score reconciliation; cross-table joins",
            suggested="Inspect the source replay's MatchID extraction and preserve the raw value."))

    # Preserve source timeline events and add structured events. No silent deduplication:
    # event_family and source_record_id make overlap visible for later reconciliation.
    events: list[dict[str, Any]] = []
    abilities: list[dict[str, Any]] = []
    interactions: list[dict[str, Any]] = []
    source_counts: Counter[str] = Counter()
    cast_lookup: dict[str, dict[str, Any]] = {}

    def add_event(table: str, idx: int, source_type: str, canonical_type: str,
                  row: dict[str, str], timestamp: float | None, round_id: Any = None,
                  actor: Any = None, target: Any = None, actor_team: Any = None,
                  target_team: Any = None, x: Any = None, y: Any = None, z: Any = None,
                  ability_id: Any = None, object_id: Any = None, status: str = OBSERVED,
                  order_status: str = "SOURCE_TIMESTAMP", notes: str = "") -> str:
        source_record_id = f"{table}:{idx}"
        eid = stable_id(replay_id, table, idx, source_type, prefix="evt_")
        events.append({
            "event_id": eid, "replay_id": replay_id, "round_id": round_id,
            "source_table": table, "source_record_id": source_record_id,
            "source_event_type": source_type, "canonical_event_type": canonical_type,
            "source_timestamp_ms": timestamp, "replay_timestamp_ms": timestamp,
            "round_timestamp_ms": None, "actor_entity_id": actor, "target_entity_id": target,
            "actor_team": actor_team, "target_team": target_team, "position_x": x,
            "position_y": y, "position_z": z, "ability_instance_id": ability_id,
            "object_instance_id": object_id, "observation_status": status,
            "event_order_status": order_status, "derivation_version": VERSION,
            "validation_status": "UNVALIDATED", "notes": notes
        })
        source_counts[table] += 1
        return eid

    # Timeline contains event labels from the parser. Keep these as observed source events.
    for i, row in enumerate(read_csv(match_dir / "timeline.csv")):
        typ = _text(row, "event") or "unknown"
        add_event("timeline.csv", i, typ, "timeline:" + typ, row,
                  _num(row, "t_ms", "abs_ms", "time_ms"), _text(row, "round"),
                  _text(row, "actor"), _text(row, "target"),
                  _text(row, "actor_team"), _text(row, "target_team"),
                  _num(row, "x"), _num(row, "y"), None,
                  notes="Timeline row preserved; may overlap with structured source tables.")

    # Round state transitions and objective events.
    for i, row in enumerate(read_csv(match_dir / "rounds.csv")):
        rnd = _text(row, "round")
        start = _num(row, "start_ms")
        barrier = _num(row, "barrier_ms")
        result = _num(row, "result_ms")
        if start is not None:
            add_event("rounds.csv", i, "round_start", "ROUND_START", row, start, rnd,
                      notes="Round start timestamp from parser output.")
        if barrier is not None:
            add_event("rounds.csv", i, "barrier_drop", "BARRIER_DROP", row, barrier, rnd,
                      notes=_text(row, "barrier_source") or "")
        for col, typ in (("plant_ms", "SPIKE_PLANT"), ("result_ms", "ROUND_RESULT")):
            ts = _num(row, col)
            flag = _text(row, "spike_planted") if col == "plant_ms" else _text(row, "result")
            if ts is not None and flag and flag.lower() not in ("0", "false", "none", "nan", ""):
                add_event("rounds.csv", i, col, typ, row, ts, rnd,
                          notes=f"{col} derived from rounds.csv; result={flag}")
        # Defuse/explosion may have booleans but no dedicated timestamp in current schema.
        for flag_col, typ in (("spike_defused", "SPIKE_DEFUSE"), ("spike_exploded", "SPIKE_EXPLODE")):
            flag = _text(row, flag_col)
            if flag and flag.lower() not in ("0", "false", "none", "nan", ""):
                add_event("rounds.csv", i, flag_col, typ, row, result, rnd,
                          status=DERIVED, order_status="ROUND_RESULT_TIMESTAMP_PROXY",
                          notes="Source table records the outcome flag but no dedicated event timestamp; result timestamp used only as proxy.")

    # Kills.
    for i, row in enumerate(read_csv(match_dir / "kills.csv")):
        ts = _num(row, "abs_ms", "t_ms")
        add_event("kills.csv", i, "kill_record", "KILL", row, ts,
                  _text(row, "round"), _text(row, "killer"), _text(row, "victim"),
                  _text(row, "killer_team"), _text(row, "victim_team"),
                  notes="KillData-derived row; actor identities retain source parser labels.")

    # Ability casts.
    cast_rows = read_csv(match_dir / "utility_casts.csv")
    linked_rows = read_csv(match_dir / "utility_casts_linked.csv")
    linked_by_key: dict[str, dict[str, str]] = {}
    for lr in linked_rows:
        ck = _text(lr, "cast_key")
        if ck:
            linked_by_key[ck] = lr
    for i, row in enumerate(cast_rows):
        ck = _text(row, "cast_key") or f"row_{i}"
        linked = linked_by_key.get(ck, {})
        ability_id = "abil_" + stable_id(replay_id, ck, _text(row, "round"), prefix="")
        eid = add_event("utility_casts.csv", i, "utility_cast", "ABILITY_CAST", row,
                  _num(row, "t_ms", "abs_ms"), _text(row, "round"),
                  _text(row, "caster_player"), None, _text(row, "caster_team"), None,
                  _num(row, "cast_x"), _num(row, "cast_y"), _num(row, "cast_z"),
                  ability_id, _text(linked, "obj_cls"),
                  notes="Cast record; object/ability association is inherited from linked table and may be heuristic.")
        ability = {
            "replay_id": replay_id, "round_id": _text(row, "round"),
            "ability_instance_id": ability_id, "cast_event_id": eid, "cast_key": ck,
            "caster_entity_id": _text(row, "caster_player"), "caster_team": _text(row, "caster_team"),
            "agent": _text(row, "agent"), "ability": _text(linked, "ability"),
            "tier": _text(linked, "tier"), "cast_timestamp_ms": _num(row, "t_ms", "abs_ms"),
            "position_x": _num(row, "cast_x"), "position_y": _num(row, "cast_y"),
            "position_z": _num(row, "cast_z"),
            "lifecycle_status": "CAST_OBSERVED_LIFECYCLE_INCOMPLETE",
            "object_class": _text(linked, "obj_cls"), "link_basis": _text(linked, "link_basis"),
            "link_delta_ms": _num(linked, "link_dt_ms"), "source_record_id": f"utility_casts.csv:{i}",
            "confidence_status": "HEURISTIC_LINK" if _text(linked, "link_basis") else "UNRESOLVED",
            "derivation_version": VERSION
        }
        abilities.append(ability)
        cast_lookup[ck] = ability

    # Effect rows: preserve each effect as a separate interaction; no claims of causal value.
    for i, row in enumerate(read_csv(match_dir / "utility_effects.csv")):
        ck = _text(row, "cast_key")
        a = cast_lookup.get(ck or "")
        typ = _text(row, "tag") or "unknown_effect"
        iid = stable_id(replay_id, "utility_effects.csv", i, ck, typ, prefix="int_")
        interactions.append({
            "interaction_id": iid, "replay_id": replay_id, "round_id": _text(row, "round"),
            "ability_instance_id": a["ability_instance_id"] if a else None, "cast_key": ck,
            "interaction_type": typ, "timestamp_ms": _num(row, "t_ms"),
            "target_entity_id": _text(row, "target_player"),
            "target_team": _text(row, "target_team"), "value": _num(row, "per_target_value", "cast_total_value"),
            "effect_lag_s": _num(row, "effect_lag_s"), "source_table": "utility_effects.csv",
            "source_record_id": f"utility_effects.csv:{i}", "observation_status": OBSERVED,
            "confidence_status": "CAST_KEY_MATCH" if a else "UNLINKED_EFFECT",
            "derivation_version": VERSION,
            "notes": "Recorded effect tag; not proof of tactical benefit or causation."
        })
        add_event("utility_effects.csv", i, typ, "ABILITY_EFFECT", row,
                  _num(row, "t_ms"), _text(row, "round"),
                  _text(row, "caster_player"), _text(row, "target_player"),
                  _text(row, "caster_team"), _text(row, "target_team"),
                  _num(row, "cast_x"), _num(row, "cast_y"), _num(row, "cast_z"),
                  a["ability_instance_id"] if a else None, None,
                  notes=f"effect_lag_s={_text(row, 'effect_lag_s')}; association={('cast_key match' if a else 'unlinked')}")

    # Validation: required identity, coordinates and association coverage.
    if map_meta["map_identity_status"] != "VERIFIED":
        findings.append(make_finding(replay_id, "map_identity", "WARN", "NOT_CHECKED",
            "Verified map identity was not supplied to the spatial layer.", "match.csv",
            blocked="map-region assignment; map/site comparisons",
            suggested="Supply a verified map metadata JSON keyed by replay_id or source match_id, with map_evidence."))
    if not cast_rows:
        findings.append(make_finding(replay_id, "utility_casts_present", "WARN", "NOT_SUPPORTED",
            "No utility_casts.csv records were available.", "utility_casts.csv",
            blocked="ability lifecycle and utility analysis",
            suggested="Confirm parser capabilities for this replay/build."))
    if not read_csv(match_dir / "player_positions.csv"):
        findings.append(make_finding(replay_id, "player_trajectories", "WARN", "NOT_SUPPORTED",
            "No continuous player-position table exists in the current parser outputs; cast coordinates are not player trajectories.",
            "player_positions.csv", blocked="movement paths; occupancy duration; rotation-time analysis",
            suggested="Implement a source-backed position extractor only if the replay exposes suitable position samples."))
    # Check missing timestamps and ambiguous links.
    missing_ts = sum(1 for e in events if e["replay_timestamp_ms"] is None)
    if missing_ts:
        findings.append(make_finding(replay_id, "event_timestamp_coverage", "WARN", "WARN",
            f"{missing_ts} canonical event rows have no usable timestamp.", "canonical_events.csv",
            blocked="precise temporal sequence for affected events",
            suggested="Inspect source fields and timestamp conversion; preserve untimed events without ordering claims."))
    unlinked_effects = sum(1 for x in interactions if x["confidence_status"] == "UNLINKED_EFFECT")
    if unlinked_effects:
        findings.append(make_finding(replay_id, "effect_cast_linkage", "WARN", "WARN",
            f"{unlinked_effects} effect rows could not be joined to a cast by cast_key.",
            "utility_effects.csv", blocked="ability-specific effect attribution",
            suggested="Inspect cast-key normalization and retain alternate candidate links."))
    for i, a in enumerate(abilities):
        lag = a.get("link_delta_ms")
        if lag is not None and abs(lag) > 10000:
            findings.append(make_finding(replay_id, "ability_link_time_delta", "WARN", "WARN",
                f"Ability/object link has a time delta of {lag} ms; review link_basis before use.",
                "utility_casts_linked.csv", a["source_record_id"], expected="within documented ability-specific window",
                observed=lag, blocked="ability-object lifecycle confidence",
                suggested="Validate ability-specific association rules; do not drop the record automatically."))

    # Output map metadata and manifest.
    out = output_dir / replay_id
    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / "canonical_events.csv", events, EVENT_FIELDS)
    write_csv(out / "ability_instances.csv", abilities, ABILITY_FIELDS)
    write_csv(out / "ability_interactions.csv", interactions, INTERACTION_FIELDS)
    write_csv(out / "validation_findings.csv", findings, FINDING_FIELDS)
    (out / "map_metadata.json").write_text(json.dumps(map_meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    generated = []
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name != "manifest.json":
            generated.append({"path": p.name, "bytes": p.stat().st_size, "sha256": sha256_file(p),
                              "rows": _count_rows(p)})
    manifest = {
        "manifest_schema_version": SCHEMA_VERSION,
        "spatial_layer_version": VERSION,
        "replay_id": replay_id,
        "source_match_id": source_match_id,
        "source_match_key": match_key,
        "source_directory": str(match_dir),
        "input_files": source_manifest,
        "game_build": _text(match_row, "build"),
        "duration_s": _num(match_row, "duration_s"),
        "map": map_meta,
        "capabilities": {
            "canonical_events": "AVAILABLE" if events else "EMPTY",
            "ability_instances": "AVAILABLE" if abilities else "EMPTY",
            "ability_interactions": "AVAILABLE" if interactions else "EMPTY",
            "continuous_player_trajectories": "NOT_SUPPORTED_BY_CURRENT_EXPORT",
            "map_region_assignment": "BLOCKED_UNTIL_VERIFIED_MAP_GEOMETRY",
            "visibility_reconstruction": "NOT_IMPLEMENTED",
            "tactical_causality": "NOT_CLAIMED"
        },
        "counts": {
            "canonical_events": len(events), "ability_instances": len(abilities),
            "ability_interactions": len(interactions), "validation_findings": len(findings),
            "source_rows_by_table": dict(source_counts)
        },
        "runtime": {"python": sys.version.split()[0], "platform": platform.platform()},
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "generated_files": generated,
        "notes": [
            "This is a post-processing layer over existing parser CSVs; it does not decode raw VRF.",
            "No map identity or geometry is invented.",
            "Canonical events from multiple source tables may refer to the same underlying game event; no silent deduplication is performed.",
            "Ability cast records are not proof of unique button presses or tactical success."
        ]
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest

def _count_rows(path: Path) -> int | None:
    if path.suffix.lower() != ".csv":
        return None
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return max(sum(1 for _ in csv.reader(f)) - 1, 0)

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input_root", type=Path, help="Parser output root, matches/ directory, or one match tables directory")
    ap.add_argument("--out", type=Path, default=Path("spatial_output"))
    ap.add_argument("--map-metadata", type=Path, default=None,
                    help="Optional verified map metadata JSON. Requires map_id and map_evidence.")
    args = ap.parse_args()
    matches = locate_match_dirs(args.input_root)
    if not matches:
        ap.error(f"No match output directories found under {args.input_root}")
    manifests = []
    for key, directory in matches:
        manifest = process_match(key, directory, args.out, args.map_metadata)
        manifests.append(manifest)
        print(json.dumps({
            "replay_id": manifest["replay_id"],
            "source_match_id": manifest["source_match_id"],
            "map_identity_status": manifest["map"]["map_identity_status"],
            "events": manifest["counts"]["canonical_events"],
            "ability_instances": manifest["counts"]["ability_instances"],
            "interactions": manifest["counts"]["ability_interactions"],
            "validation_findings": manifest["counts"]["validation_findings"]
        }, sort_keys=True))
    summary = {
        "schema_version": SCHEMA_VERSION, "spatial_layer_version": VERSION,
        "replays_processed": len(manifests),
        "manifests": [{"replay_id": m["replay_id"], "manifest_path": str(args.out / m["replay_id"] / "manifest.json"),
                       "counts": m["counts"], "map": m["map"]} for m in manifests]
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "batch_manifest.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Processed {len(manifests)} replay output(s). Wrote {args.out / 'batch_manifest.json'}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
