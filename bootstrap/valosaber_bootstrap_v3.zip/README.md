# Valosaber pipeline bootstrap v3.0.0

Built 2026-11-01 from repo commit c78f493. Serves two consumers from one raw `.vrf` replay:
the **meta-analysis agent** (15 native-resolution data groups, `analytics_tables/`) and the **statistics analyst** (schema-2 shard, `stats_shard/`).

## Start here (in this order)
1. `AGENT_TASK.md` is the task you are given. Read all of it, including the ADDENDUM at the end.
2. `docs/EXTRACTION_REQUIREMENTS.md` is the meta agent's contract for `analytics_tables/` (verbatim).
3. `knowledge/` holds what the project has learned: `Reference/Replay Data Guide.md` (traps in the data), agents, classes, maps, abilities,
   ADRs (`Decisions/`), shard schema, metrics. Names are confirmed or they stay as codenames.
4. `golden_sample/` is the one replay whose correct answer is known. Run `python3 parser/golden_sample_test.py golden_sample/shard golden_sample/export`
   before trusting any code change. A pass means EXPORT_PIPELINE_VALIDATED (export to shard logic only), not that a raw replay was parsed.

## Layout
| Path | Contents |
|---|---|
| `parser/` | `colab_bootstrap.py` (installs a registered vrfkit), `batch_process.py` (folder of replays to shards), `valosaber.py`, `shard_checks.py`, `golden_sample_test.py`, `ingest.py`, `baselines.py`, `register_vrfkit.py`, `skill/` (cast and table builders, `codenames.json`), notebook |
| `data/` | name lookup (build 13.08), `agent_classes.json`, `vrfkit_supported_builds.json` (registry), pipeline guide |
| `scripts/ schemas/ config/ ontology/ run_pipeline.py` | the meta agent's earlier files, unchanged. `run_pipeline.py` is the old exporter (fixed folders); use `parser/batch_process.py` instead. `scripts/spatial_layer.py` expects CSV tables this pipeline does not yet produce |
| `golden_sample/` | shard, events and manifest of the sample export, expected values |
| `bin/` | empty on purpose (see `bin/README.txt`) |
| `PACKAGE_MANIFEST.json` | SHA-256 of every file here |

## Run
```
python3 parser/colab_bootstrap.py          # stops with REFUSING if no registered vrfkit is found
python3 parser/batch_process.py --replays REPLAYS --outbox OUTBOX --vrfkit bin/vrfkit --lookup data/name_lookup_build13_08.json --only ONE_REPLAY.vrf
```
Run one replay first and read its `status.json`. A replay whose build is not in the registry stops with `unsupported_build`; that is the correct
result, not something to work around. Never fill, default or invent a value; never run a binary that is not registered.

## Known limits (today)
- Only release-13.08 Swiftplay is verified. Patch 13.09 (Hush) is unsupported by the pinned vrfkit; its codename and ID are unknown.
- Economy was all zero in the sample (mode or decode gap, unknown). `characterUltimateUsed` over-reports about 50%.
- Not yet built: matches/rounds winners table, spike_events, economy, ability lifecycle, utility_objects, player_effects, world_state, map_identity, native player_state, the completeness report, tests A to I from the requirements.
